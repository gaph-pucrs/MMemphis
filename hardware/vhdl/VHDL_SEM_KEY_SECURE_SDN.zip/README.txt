Esse hw VHDL deve ser comparado com a versao git hash 405f821a95b370aa9fa1e6ffaff1dc86d7241cdf que possui o mesmo hardware soh que com a implementacao da key
O HW compactado nesta pasta deverá ser usado para comparacao de area e power em relacao a hash 405f821a95b370aa9fa1e6ffaff1dc86d7241cdf
